import io
import os
import hashlib
import shutil
import json
import socket
import threading
import time
import zipfile
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Callable, Final, List, Optional, Set, Dict, Any, Tuple, Union, IO, BinaryIO
from downloader.config import Config
from downloader.constants import HASH_file_does_not_exist, STORAGE_PATHS_SET
from downloader.error import DownloaderError
from downloader.job_system import ActivityTracker
from downloader.logger import Logger, OffLogger
from downloader.path_package import PathPackage
is_windows: Final = os.name == 'nt'
COPY_BUFSIZE: Final = 256 * 1024
class FileSystemFactory:
    def __init__(self, config: Config, path_dictionary: Dict[str, str], logger: Logger, activity_tracker: ActivityTracker, time_monotonic: Callable[[], float] = time.monotonic) -> None:
        self._config = config
        self._path_dictionary = path_dictionary
        self._logger = logger
        self._activity_tracker = activity_tracker
        self._time_monotonic = time_monotonic
        self._unique_temp_filenames: Set[Optional[str]] = set()
        self._unique_temp_filenames.add(None)
        self._shared_state = FsSharedState()
        self._lazy_json_init = False
    def create_for_system_scope(self) -> 'FileSystem':
        return self.create_for_config(self._config)
    def create_for_config(self, config) -> 'FileSystem':
        return _FileSystem(config['base_path'], self._path_dictionary, self._logger, self._unique_temp_filenames, self._shared_state, self._activity_tracker, self._time_monotonic)
    def cancel_ongoing_operations(self) -> None:
        self._shared_state.interrupting_operations = True
class FileSystem(ABC):
    @abstractmethod
    def free_spaces(self) -> dict[str, int]:
        ""
    @abstractmethod
    def resolve(self, path: str) -> str:
        ""
    @abstractmethod
    def is_file(self, path: str, use_cache: bool = True) -> bool:
        ""
    @abstractmethod
    def are_files(self, file_pkgs: List[PathPackage]) -> Tuple[List[PathPackage], List[PathPackage]]:
        ""
    @abstractmethod
    def print_debug(self) -> None:
        ""
    @abstractmethod
    def is_folder(self, path: str) -> bool:
        ""
    @abstractmethod
    def precache_is_file_with_folders(self, folders: List[PathPackage], recheck: bool = False) -> None:
        ""
    @abstractmethod
    def read_file_contents(self, path: str) -> str:
        ""
    @abstractmethod
    def write_file_contents(self, path: str, content: str) -> int:
        ""
    @abstractmethod
    def read_file_bytes(self, path: str) -> io.BytesIO:
        ""
    @abstractmethod
    def touch(self, path: str) -> None:
        ""
    @abstractmethod
    def move(self, source: str, target: str, make_parent_target: bool = True) -> None:
        ""
    @abstractmethod
    def copy(self, source: str, target: str) -> None:
        ""
    @abstractmethod
    def append(self, source: str, target: str) -> None:
        ""
    @abstractmethod
    def hash(self, path: str) -> str:
        ""
    @abstractmethod
    def size(self, path: str) -> int:
        ""
    @abstractmethod
    def make_dirs(self, path: str) -> None:
        ""
    @abstractmethod
    def make_dirs_parent(self, path: str) -> None:
        ""
    @abstractmethod
    def folder_has_items(self, path: str) -> bool:
        ""
    @abstractmethod
    def remove_folder(self, path: str) -> Optional[Exception]:
        ""
    @abstractmethod
    def download_target_path(self, path: str) -> str:
        ""
    @abstractmethod
    def write_incoming_stream(self, in_stream: Any, target_path: str, timeout: int, /) -> tuple[int, str]:
        ""
    @abstractmethod
    def write_stream_to_data(self, in_stream: Any, calc_md5: bool, timeout: int, /) -> Tuple[io.BytesIO, str]:
        ""
    @abstractmethod
    def unlink(self, path: str, verbose: bool = True) -> Optional[Exception]:
        ""
    @abstractmethod
    def load_dict_from_transfer(self, source: str, transfer: Union[str, io.BytesIO], /) -> Dict[str, Any]:
        ""
    @abstractmethod
    def load_dict_from_file(self, file: str) -> Dict[str, Any]:
        ""
    @abstractmethod
    def save_json_on_zip(self, db: Dict[str, Any], path: str) -> None:
        ""
    @abstractmethod
    def save_json(self, db: Dict[str, Any], path: str) -> None:
        ""
    @abstractmethod
    def unzip_contents(self, transfer: Union[str, io.BytesIO], target_path: Union[str, Dict[str, str]], test_info: Any, /) -> None:
        ""
    @abstractmethod
    def turn_off_logs(self) -> None:
        ""
class ReadOnlyFileSystem:
    def __init__(self, fs: FileSystem) -> None:
        self._fs = fs
    def is_file(self, path):
        return self._fs.is_file(path)
    def are_files(self, file_pkgs: List[PathPackage]) -> Tuple[List[PathPackage], List[PathPackage]]:
        return self._fs.are_files(file_pkgs)
    def is_folder(self, path):
        return self._fs.is_folder(path)
    def precache_is_file_with_folders(self, folders: List[PathPackage], recheck: bool = False):
        return self._fs.precache_is_file_with_folders(folders, recheck)
    def download_target_path(self, path):
        return self._fs.download_target_path(path)
    def read_file_contents(self, path):
        return self._fs.read_file_contents(path)
    def read_file_bytes(self, path: str) -> io.BytesIO:
        return self._fs.read_file_bytes(path)
    def load_dict_from_file(self, file: str) -> Dict[str, Any]:
        return self._fs.load_dict_from_file(file)
    def load_dict_from_transfer(self, source: str, transfer):
        return self._fs.load_dict_from_transfer(source, transfer)
    def folder_has_items(self, path):
        return self._fs.folder_has_items(path)
    def hash(self, path):
        return self._fs.hash(path)
    def size(self, path):
        return self._fs.size(path)
    def unlink(self, file_path, verbose: bool=False):
        raise FileWriteError(f"Cannot delete file '{file_path}' from read-only filesystem wrapper")
class FsError(DownloaderError): pass
class FsOperationsError(FsError): pass
class FolderCreationError(FsError): pass
class FileCopyError(FsError): pass
class UnzipError(FsError): pass
class FileReadError(FsError): pass
class FileWriteError(FsError): pass
class FsTimeoutError(FsError): pass
class _FileSystem(FileSystem):
    def __init__(self, base_path: str, path_dictionary: Dict[str, str], logger: Logger, unique_temp_filenames: Set[Optional[str]], shared_state: 'FsSharedState', activity_tracker: ActivityTracker, time_monotonic: Callable[[], float] = time.monotonic) -> None:
        self._base_path = base_path
        self._path_dictionary = path_dictionary
        self._logger = logger
        self._unique_temp_filenames = unique_temp_filenames
        self._shared_state = shared_state
        self._activity_tracker = activity_tracker
        self._time_monotonic = time_monotonic
        self._quick_hit = 0
        self._slow_hit = 0
    def free_spaces(self) -> dict[str, int]:
        mounts = {}
        try:
            with open("/proc/mounts") as f:
                for line in f:
                    parts = line.split()
                    if len(parts) < 2:
                        continue
                    mountpoint = parts[1]
                    if mountpoint not in mounts and mountpoint in STORAGE_PATHS_SET:
                        try:
                            mounts[mountpoint] = shutil.disk_usage(mountpoint).free
                        except OSError:
                            pass
        except FileNotFoundError:
            pass
        return mounts
    def resolve(self, path: str) -> str:
        return str(Path(path).resolve())
    def is_file(self, path: str, use_cache: bool = True) -> bool:
        full_path = self._path(path)
        if use_cache and self._shared_state.contains_file(full_path):
            self._quick_hit += 1
            return True
        elif os.path.isfile(full_path):
            self._slow_hit += 1
            self._shared_state.add_file(full_path)
            return True
        return False
    def are_files(self, file_pkgs: List[PathPackage]) -> Tuple[List[PathPackage], List[PathPackage]]:
        are, not_sure = self._shared_state.contained_file_pkgs(file_pkgs)
        bulk_add = []
        nope = []
        for f in not_sure:
            if os.path.isfile(f.full_path):
                bulk_add.append(f.full_path)
                are.append(f)
            else:
                nope.append(f)
        self._shared_state.add_many_files(bulk_add)
        return are, nope
    def print_debug(self) -> None:
        self._logger.debug('IS_FILE quick hits: %s slow hits: %s', self._quick_hit, self._slow_hit)
    def is_folder(self, path: str) -> bool:
        return os.path.isdir(self._path(path))
    def precache_is_file_with_folders(self, folders: List[PathPackage], recheck: bool = False) -> None:
        not_checked_folders = folders if recheck else self._shared_state.consult_not_checked_folders(folders)
        files = []
        for folder_pkg in not_checked_folders:
            try:
                files.extend([f.path for f in os.scandir(folder_pkg.full_path) if f.is_file()])
            except OSError as e: continue
            except Exception as e:
                self._logger.debug('precache_is_file_with_folders error:', e)
                return
        self._shared_state.add_many_files(files)
    def read_file_bytes(self, path: str) -> io.BytesIO:
        full_path = self._path(path)
        self._debug_log('Reading file contents', (path, full_path))
        with open(full_path, 'rb') as file:
            return io.BytesIO(file.read())
    def read_file_contents(self, path: str) -> str:
        full_path = self._path(path)
        self._debug_log('Reading file contents', (path, full_path))
        with open(full_path, 'r') as f:
            return f.read()
    def write_file_contents(self, path: str, content: str) -> int:
        full_path = self._path(path)
        self._debug_log('Writing file contents', (path, full_path))
        with open(full_path, 'w') as f:
            return f.write(content)
    def touch(self, path: str) -> None:
        full_path = self._path(path)
        self._debug_log('Touching', (path, full_path))
        Path(full_path).touch()
    def move(self, source: str, target: str, make_parent_target: bool = True) -> None:
        if make_parent_target: self._makedirs(self._parent_folder(target))
        full_source = self._path(source)
        full_target = self._path(target)
        self._debug_log('Moving', (source, full_source), (target, full_target))
        os.replace(full_source, full_target)
        self._shared_state.remove_file(full_source)
        self._shared_state.add_file(full_target)
    def copy(self, source: str, target: str) -> None:
        full_source = self._path(source)
        full_target = self._path(target)
        self._debug_log('Copying', (source, full_source), (target, full_target))
        try:
            with open(full_source, 'rb') as fsource, open(full_target, 'wb') as ftarget:
                while True:
                    data = fsource.read(COPY_BUFSIZE)
                    if not data:
                        break
                    self._activity_tracker.track(self._time_monotonic())
                    ftarget.write(data)
            self._shared_state.add_file(full_target)
        except Exception as e:
            self._logger.debug(e)
            raise FileCopyError(f"Cannot copy '{source}' to '{target}'") from e
    def append(self, source: str, target: str) -> None:
        full_source = self._path(source)
        full_target = self._path(target)
        self._debug_log('Appending', (source, full_source), (target, full_target))
        try:
            with open(full_source, 'rb') as fsource, open(full_target, 'ab') as ftarget:
                while True:
                    data = fsource.read(COPY_BUFSIZE)
                    if not data:
                        break
                    ftarget.write(data)
        except Exception as e:
            self._logger.debug(e)
            raise FileCopyError(f"Cannot append '{source}' to '{target}'") from e
    def hash(self, path: str) -> str:
        try:
            return hash_file(self._path(path))
        except Exception as e:
            self._logger.debug(e)
            return HASH_file_does_not_exist
    def size(self, path: str) -> int:
        try:
            return os.path.getsize(self._path(path))
        except Exception as e:
            self._logger.debug(e)
            return -1
    def make_dirs(self, path: str) -> None:
        self._makedirs(self._path(path))
    def make_dirs_parent(self, path: str) -> None:
        self._makedirs(self._parent_folder(path))
    def _parent_folder(self, path: str) -> str:
        result = absolute_parent_folder(self._path(path))
        if is_windows:
            result = self._path(result)
        return result
    def _makedirs(self, target: str) -> None:
        try:
            os.makedirs(target, exist_ok=True)
        except FileExistsError as e:
            if e.errno == 17:
                return
            raise e
        except Exception as e:
            self._logger.debug(e)
            raise FolderCreationError(target) from e
    def folder_has_items(self, path: str) -> bool:
        try:
            iterator = os.scandir(self._path(path))
            for _ in iterator:
                iterator.close()
                return True
        except OSError as e:
            self._ignore_error(e)
        return False
    def remove_folder(self, path: str) -> Optional[Exception]:
        full_path = self._path(path)
        self._debug_log('Deleting empty folder', (path, full_path))
        try:
            os.rmdir(full_path)
        except Exception as e:
            return e
        return None
    def _ignore_error(self, e: Exception) -> None:
        self._logger.debug(e)
        self._logger.debug('Ignoring error.')
    def download_target_path(self, path: str) -> str:
        return self._path(path)
    def write_incoming_stream(self, in_stream: Any, target_path: str, timeout: int, /) -> tuple[int, str]:
        last_data_time = self._time_monotonic()
        md5_hasher = hashlib.md5()
        file_size = 0
        with open(target_path, 'wb') as out_file:
            while True:
                if self._shared_state.interrupting_operations:
                    raise FsOperationsError("File system operations have been disabled.")
                try:
                    chunk = in_stream.read(COPY_BUFSIZE)
                    if not chunk:
                        break
                    last_data_time = self._time_monotonic()
                    self._activity_tracker.track(last_data_time)
                    out_file.write(chunk)
                    md5_hasher.update(chunk)
                    file_size += len(chunk)
                except socket.timeout:
                    elapsed_time = self._time_monotonic() - last_data_time
                    if elapsed_time > timeout:
                        raise FsTimeoutError(f"Copy operation timed after being stalled for {timeout} seconds.")
        return file_size, md5_hasher.hexdigest()
    def write_stream_to_data(self, in_stream: Any, calc_md5: bool, timeout: int, /) -> Tuple[io.BytesIO, str]:
        last_data_time = self._time_monotonic()
        buf = io.BytesIO()
        md5_hasher = hashlib.md5() if calc_md5 else None
        while True:
            if self._shared_state.interrupting_operations:
                raise FsOperationsError("File system operations have been disabled.")
            try:
                chunk = in_stream.read(COPY_BUFSIZE)
                if not chunk:
                    break
                last_data_time = self._time_monotonic()
                self._activity_tracker.track(last_data_time)
                buf.write(chunk)
                if md5_hasher is not None:
                    md5_hasher.update(chunk)
            except socket.timeout:
                elapsed_time = self._time_monotonic() - last_data_time
                if elapsed_time > timeout:
                    raise FsTimeoutError(f"Copy operation timed after being stalled for {timeout} seconds.")
        buf.seek(0)
        return buf, md5_hasher.hexdigest() if md5_hasher is not None else ''
    def unlink(self, path: str, verbose: bool = True) -> Optional[Exception]:
        verbose = verbose and not path.startswith('/tmp/')
        return self._unlink(path, verbose)
    def load_dict_from_transfer(self, source: str, transfer: Union[str, io.BytesIO]) -> Dict[str, Any]:
        if isinstance(transfer, str):
            try:
                return self.load_dict_from_file(transfer)
            finally:
                self._unlink(transfer, False)
        else: return self._load_dict_from_data(source, transfer)
    def load_dict_from_file(self, path: str) -> Dict[str, Any]:
        full_path = self._path(path)
        self._debug_log('Loading dict from file', (path, full_path))
        suffix = Path(full_path).suffix.lower()
        if suffix == '.json':
            with open(full_path, "rb") as f:
                return _json_loads_from_binaryio(f)
        elif suffix == '.zip':
            return load_json_from_zip(full_path)
        else:
            raise FileReadError('File type "%s" not supported' % suffix)
    def _load_dict_from_data(self, source: str, data: io.BytesIO) -> Dict[str, Any]:
        self._logger.debug('Loading dict from data: ', source)
        suffix = Path(source).suffix.lower()
        if suffix == '.json':
            return _json_load_from_bytesio(data)
        elif suffix == '.zip':
            return load_json_from_zip(data)
        else:
            raise FileReadError('File type "%s" not supported: %s' % (suffix, source))
    def save_json_on_zip(self, db: Dict[str, Any], path: str) -> None:
        full_path = self._path(path)
        json_name = Path(path).stem
        zip_path = Path(full_path).absolute()
        self._debug_log('Saving json on zip', (path, full_path))
        with zipfile.ZipFile(zip_path, 'w') as zipf:
            zipf.writestr(json_name, _json_dump_binary(db))
    def save_json(self, db: Dict[str, Any], path: str) -> None:
        full_path = self._path(path)
        self._debug_log('Saving json', (path, full_path))
        with open(full_path, 'wb') as f:
            _json_dump_to_file(db, f)
    def unzip_contents(self, zip_file: Union[str, io.BytesIO], target_path: Union[str, Dict[str, str]], test_info: Any, /) -> None:
        if not isinstance(zip_file, str):
            self._logger.debug('Unzipping contents from io.BytesIO.')
        else:
            self._logger.debug('Unzipping contents: ', zip_file)
        try:
            with zipfile.ZipFile(zip_file, 'r') as zipf:
                if isinstance(target_path, str):
                    zipf.extractall(target_path)
                    return
                files_to_unzip = target_path
                for member in zipf.infolist():
                    if member.filename not in files_to_unzip:
                        continue
                    if self._shared_state.interrupting_operations:
                        raise FsOperationsError("File system operations have been disabled.")
                    file_path = files_to_unzip[member.filename]
                    with zipf.open(member) as source, open(file_path, 'wb') as target:
                        while True:
                            buf = source.read(COPY_BUFSIZE)
                            if not buf:
                                break
                            self._activity_tracker.track(self._time_monotonic())
                            target.write(buf)
        except Exception as e:
            self._logger.debug(e)
            raise UnzipError(f"Cannot unzip '{zip_file}' ['{target_path if isinstance(target_path, str) else len(target_path)}']") from e
        finally:
            if isinstance(zip_file, str):
                self._unlink(zip_file, verbose=False)
    def _debug_log(self, message: str, path: Tuple[str, str], target: Optional[Tuple[str, str]] = None) -> None:
        if path[0][0] == '/':
            if target is None:
                self._logger.debug('%s "%s"', message, path[0])
            else:
                self._logger.debug('%s "%s" to "%s"', message, path[0], target[0])
        else:
            if target is None:
                self._logger.debug('%s "%s". %s', message, path[0], path[1])
            else:
                self._logger.debug('%s "%s" to "%s". %s -> %s', message, path[0], target[0], path[1], target[1])
    def turn_off_logs(self) -> None:
        self._logger = OffLogger()
    def _unlink(self, path: str, verbose: bool) -> Optional[Exception]:
        full_path = self._path(path)
        if verbose:
            self._logger.print(f'Removing {path} ({full_path})')
        else:
            self._debug_log('Removing', (path, full_path))
        try:
            Path(full_path).unlink()
            self._shared_state.remove_file(full_path)
            return None
        except Exception as e:
            self._logger.debug('unlink error: ', e)
            return e
    def _path(self, path: str) -> str:
        if path[0] == '/' or os.path.isabs(path):
            return path
        return os.path.join(self._base_path, path)
class InvalidFileResolution(DownloaderError):
    pass
def hash_file(path: str) -> str:
    with open(path, "rb") as f:
        file_hash = hashlib.md5()
        chunk = f.read(COPY_BUFSIZE)
        while chunk:
            file_hash.update(chunk)
            chunk = f.read(COPY_BUFSIZE)
        return file_hash.hexdigest()
def absolute_parent_folder(absolute_path: str) -> str:
    return str(Path(absolute_path).parent)
def load_json_from_zip(input: Union[str, io.BytesIO]) -> Dict[str, Any]:
    with zipfile.ZipFile(input) as jsonzipf:
        namelist = jsonzipf.namelist()
        if len(namelist) != 1:
            raise FileReadError('Could not load zipped json, because it has %s elements!' % len(namelist))
        with jsonzipf.open(namelist[0]) as store_json_file:
            return _json_loads_from_iobytes(store_json_file)
class FsSharedState:
    def __init__(self) -> None:
        self.interrupting_operations = False
        self._files: set[str] = set()
        self._files_lock = threading.Lock()
        self._cached_folders: set[str] = set()
        self._cached_folders_lock = threading.Lock()
    def consult_not_checked_folders(self, folders: List[PathPackage]) -> List[PathPackage]:
        precaching_folders = []
        with self._cached_folders_lock:
            for folder_pkg in folders:
                if folder_pkg.full_path not in self._cached_folders:
                    self._cached_folders.add(folder_pkg.full_path)
                    precaching_folders.append(folder_pkg)
        return precaching_folders
    def contains_file(self, path: str) -> bool:
        with self._files_lock:
            return path in self._files
    def contained_file_pkgs(self, pkgs: List[PathPackage]) -> Tuple[List[PathPackage], List[PathPackage]]:
        if len(pkgs) == 0: return [], []
        contained = []
        foreigns = []
        with self._files_lock:
            for p in pkgs:
                if p.full_path in self._files:
                    contained.append(p)
                else:
                    foreigns.append(p)
        return contained, foreigns
    def add_many_files(self, paths: List[str]) -> None:
        if len(paths) == 0: return
        with self._files_lock:
            self._files.update(paths)
    def add_file(self, path: str) -> None:
        with self._files_lock:
            self._files.add(path)
    def remove_file(self, path: str) -> None:
        with self._files_lock:
            self._files.discard(path)
def _json_load_from_bytesio(data: io.BytesIO) -> Dict[str, Any]:
    return json.loads(data.getvalue().decode("utf-8"))
def _json_loads_from_iobytes(data: IO[bytes]) -> Dict[str, Any]:
    return json.loads(data.read().decode("utf-8"))
def _json_loads_from_binaryio(data: BinaryIO) -> Dict[str, Any]:
    return json.loads(data.read().decode("utf-8"))
def _json_dump_binary(obj: Dict[str, Any]) -> bytes:
    return json.dumps(obj).encode()
def _json_dump_to_file(obj: Dict[str, Any], f: BinaryIO) -> int:
    return f.write(json.dumps(obj).encode())
