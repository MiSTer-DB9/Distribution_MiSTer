from typing import Optional
from downloader.constants import STORAGE_PATHS_PRIORITY_SEQUENCE, MEDIA_FAT, K_BASE_SYSTEM_PATH, K_BASE_PATH
from downloader.file_system import FileSystem
from downloader.logger import Logger
class ExternalDrivesRepositoryFactory:
    def create(self, file_system, logger):
        return ExternalDrivesRepository(file_system, logger)
class ExternalDrivesRepository:
    def __init__(self, file_system: FileSystem, logger: Logger) -> None:
        self._file_system = file_system
        self._logger = logger
        self._connected_drives: Optional[tuple[str, ...]] = None
    def connected_drives(self) -> tuple[str, ...]:
        if self._connected_drives is None:
            self._connected_drives = self._retrieve_connected_drives_list()
            if len(self._connected_drives) > 0:
                self._logger.debug()
                self._logger.debug('Detected following connected drives:')
                for directory in self._connected_drives:
                    self._logger.debug(directory)
                self._logger.debug()
            else:
                self._logger.debug('Detected no connected drives.')
        return self._connected_drives
    def connected_drives_except_base_path_drives(self, config):
        blocklist = set()
        if K_BASE_SYSTEM_PATH in config:
            blocklist.add(config[K_BASE_SYSTEM_PATH])
        if K_BASE_PATH in config:
            blocklist.add(config[K_BASE_PATH])
        return (drive for drive in self.connected_drives() if drive not in blocklist)
    def _retrieve_connected_drives_list(self):
        try:
            return self._drives_from_os()
        except Exception as e:
            self._logger.debug(e)
            return self._drives_from_fs()
    def _drives_from_os(self):
        connected_drives = set()
        if self._file_system.is_file('/proc/mounts'):
            for line in self._file_system.read_file_contents('/proc/mounts').splitlines():
                line = line.strip()
                if not line:
                    continue
                parts = line.split(' ')
                if len(parts) < 2:
                    continue
                mount_point = parts[1]
                if mount_point.startswith('/media/usb') or mount_point.startswith('/media/fat/cifs'):
                    connected_drives.add(mount_point)
        return tuple(drive for drive in STORAGE_PATHS_PRIORITY_SEQUENCE if drive in connected_drives)
    def _drives_from_fs(self):
        result = []
        for drive in STORAGE_PATHS_PRIORITY_SEQUENCE:
            if drive is MEDIA_FAT:
                continue
            if self._file_system.is_folder(drive):
                result.append(drive)
        return tuple(result)
