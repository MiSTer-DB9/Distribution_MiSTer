from downloader.store_migrator import MigrationBase
class MigrationV2(MigrationBase):
    version = 2
    def migrate(self, local_store) -> None:
        ""
        for db_id in local_store['dbs']:
            local_store['dbs'][db_id]['folders'] = {folder: {} for folder in local_store['dbs'][db_id]['folders']}
            for zip_id in local_store['dbs'][db_id]['zips']:
                if 'folders' in local_store['dbs'][db_id]['zips'][zip_id]:
                    local_store['dbs'][db_id]['zips'][zip_id]['folders'] = {folder: {} for folder in local_store['dbs'][db_id]['zips'][zip_id]['folders']}
                else:
                    local_store['dbs'][db_id]['zips'][zip_id]['folders'] = {}
