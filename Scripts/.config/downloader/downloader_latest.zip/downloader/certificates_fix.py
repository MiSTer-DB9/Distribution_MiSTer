import subprocess
from downloader.config import Config
from downloader.constants import DEFAULT_CURL_SSL_OPTIONS
from downloader.file_system import FileSystem
from downloader.logger import Logger
from downloader.waiter import Waiter
class CertificatesFix:
    cacert_pem_url = 'https://curl.se/ca/cacert.pem'
    def __init__(self, config: Config, file_system: FileSystem, waiter: Waiter, logger: Logger) -> None:
        self._config = config
        self._file_system = file_system
        self._waiter = waiter
        self._logger = logger
    def fix_certificates_if_needed(self) -> bool:
        self._logger.bench('CertificatesFix Fix certificates start.')
        result = self._fix_certificates_if_needed_impl()
        self._logger.bench('CertificatesFix Fix certificates done.')
        return result
    def _fix_certificates_if_needed_impl(self) -> bool:
        curl_ssl = self._config['curl_ssl'].strip().lower()
        if curl_ssl != DEFAULT_CURL_SSL_OPTIONS.strip().lower():
            return True
        parts = curl_ssl.split()
        if len(parts) != 2 or parts[0] != '--cacert':
            return True
        cacert_path = parts[1]
        if self._file_system.is_file(cacert_path):
            return self._check_cacert(cacert_path)
        self._logger.print('WARNING: cacert file at "%s" seems to be missing!' % cacert_path)
        self._get_new_cacert(cacert_path)
        return True
    def _check_cacert(self, cacert_path) -> bool:
        result = self._test_query(cacert_path)
        if result.returncode == 0:
            self._logger.debug('cacert file at "%s" seems to be fine.', cacert_path)
            return True
        self._logger.print('WARNING: cacert file at "%s" seems to be wrong!' % cacert_path)
        self._logger.print('         Return Code: %d' % result.returncode)
        if not self._unlink(cacert_path):
            return False
        return self._get_new_cacert(cacert_path)
    def _unlink(self, path) -> bool:
        err = self._file_system.unlink(path)
        if isinstance(err, OSError):
            if err.errno != 30:
                raise err
            self._logger.debug(err)
            self._logger.debug("ERROR: Could not remove certs file.")
            return False
        elif err is not None:
            self._logger.debug('WARNING: certificates_fix._unlink failed ', path, err)
            return True
        else:
            return True
    def _get_new_cacert(self, cacert_path) -> bool:
        try:
            self._file_system.touch(cacert_path)
        except OSError as _:
            self._logger.print('ERROR: cacert path is invalid!')
            return False
        self._logger.print()
        self._logger.print('Downloading new cacert file...')
        result = self._download(cacert_path)
        if result.returncode != 0:
            self._logger.print('ERROR: Download failed! %d' % result.returncode)
            return False
        self._logger.print()
        self._logger.print('New cacert file has been installed at "%s" successfully.' % cacert_path)
        self._logger.print()
        return True
    def _test_query(self, path):
        return subprocess.run(['curl', '--cacert', path, self.cacert_pem_url], stderr=subprocess.STDOUT, stdout=subprocess.DEVNULL)
    def _download(self, path):
        return subprocess.run(['curl', '--insecure', '-o', path, self.cacert_pem_url], stderr=subprocess.STDOUT)
