from downloader.job_system import WorkerResult, JobContext, ProgressReporter
from downloader.jobs.index import Index
from downloader.jobs.process_db_index_job import ProcessDbIndexJob
from downloader.jobs.process_zip_index_job import ProcessZipIndexJob
from downloader.jobs.reporters import InstallationReportImpl
from downloader.jobs.worker_context import DownloaderWorker
from downloader.jobs.wait_db_zips_job import WaitDbZipsJob
from downloader.logger import Logger
class WaitDbZipsWorker(DownloaderWorker):
    def __init__(self, logger: Logger, installation_report: InstallationReportImpl, worker_context: JobContext, progress_reporter: ProgressReporter) -> None:
        self._logger = logger
        self._installation_report = installation_report
        self._worker_context = worker_context
        self._progress_reporter = progress_reporter
    def job_type_id(self) -> int: return WaitDbZipsJob.type_id
    def reporter(self): return self._progress_reporter
    def operate_on(self, job: WaitDbZipsJob) -> WorkerResult:  # type: ignore[override]
        self._logger.bench('WaitDbZipsWorker wait start: ', job.db.db_id)
        while self._installation_report.any_in_progress_job_with_tags(job.zip_job_tags):
            self._worker_context.wait_for_other_jobs(0.1)
        self._logger.bench('WaitDbZipsWorker wait done: ', job.db.db_id)
        index = Index(files=job.db.files, folders=job.db.folders)
        zip_indexes = []
        for tag in job.zip_job_tags:
            for zip_job in self._installation_report.get_jobs_completed_by_tag(tag):
                if isinstance(zip_job, ProcessZipIndexJob):
                    zip_indexes.append(zip_job.zip_index)
            for zip_job in self._installation_report.get_jobs_failed_by_tag(tag):
                if isinstance(zip_job, ProcessZipIndexJob):
                    if len(zip_job.full_partitions) > 0:
                        return [], None
        self._logger.bench('WaitDbZipsWorker deselect_all start: ', job.db.db_id)
        store = job.store.deselect_all(zip_indexes)
        self._logger.bench('WaitDbZipsWorker deselect_all done: ', job.db.db_id)
        resulting_job = ProcessDbIndexJob(
            db=job.db,
            ini_description=job.ini_description,
            config=job.config,
            index=index,
            store=store,
        )
        self._logger.bench('WaitDbZipsWorker done: ', job.db.db_id)
        return [resulting_job], None
