import os
from typing import Optional, Union
from downloader.file_system import UnzipError
from downloader.job_system import WorkerResult, ProgressReporter
from downloader.jobs.open_zip_contents_job import OpenZipContentsJob, ZipKind
from downloader.jobs.process_db_index_worker import create_fetch_jobs, ProcessIndexCtx
from downloader.jobs.worker_context import DownloaderWorker
from downloader.logger import Logger
from downloader.path_package import PATH_PACKAGE_KIND_STANDARD, PATH_TYPE_FILE, PATH_TYPE_FOLDER, PathPackage
class OpenZipContentsWorker(DownloaderWorker):
    def __init__(self, logger: Logger, progress_reporter: ProgressReporter, process_index_ctx: ProcessIndexCtx) -> None:
        self._logger = logger
        self._progress_reporter = progress_reporter
        self._process_index_ctx = process_index_ctx
    def job_type_id(self) -> int: return OpenZipContentsJob.type_id
    def reporter(self): return self._progress_reporter
    def operate_on(self, job: OpenZipContentsJob) -> WorkerResult:  # type: ignore[override]
        self._logger.bench('OpenZipContentsWorker start: ', job.db.db_id, job.zip_id)
        zip_paths: Optional[dict[str, str]]
        if job.zip_kind == ZipKind.EXTRACT_ALL_CONTENTS:
            should_extract_all = len(job.files_to_unzip) > (0.7 * job.total_amount_of_files_in_zip)
            if should_extract_all:
                zip_paths = None
            else:
                root_zip_path = os.path.join(job.target_folder.rel_path, '')  # type: ignore[union-attr]
                zip_paths = {pkg.description.get('zip_path', None) or pkg.rel_path.removeprefix(root_zip_path): pkg.full_path for pkg in job.files_to_unzip}
        elif job.zip_kind == ZipKind.EXTRACT_SINGLE_FILES:
            should_extract_all = False
            zip_paths = {pkg.description['zip_path']: pkg.full_path for pkg in job.files_to_unzip}
        else: raise ValueError(f"Impossible kind '{job.zip_kind}' for zip '{job.zip_id}' in db '{job.db.db_id}'")
        target_path: Union[str, dict[str, str]] = job.target_folder.full_path if should_extract_all else (zip_paths or {})  # type: ignore[union-attr]
        self._process_index_ctx.file_download_session_logger.print_progress_line(job.action_text)
        self._logger.bench('OpenZipContentsWorker unzipping...', job.db.db_id, job.zip_id)
        try:
            self._process_index_ctx.file_system.unzip_contents(job.transfer_job.transfer(), target_path, (job.target_folder, job.files_to_unzip, job.filtered_data['files']))  # type: ignore[union-attr]
        except UnzipError as e:
            self._process_index_ctx.fail_ctx.swallow_error(e)
            return [], e
        self._logger.bench('OpenZipContentsWorker unzip done...', job.db.db_id, job.zip_id)
        if should_extract_all:
            if len(job.filtered_data['files']) > 0:
                job.files_to_remove = [
                    PathPackage(file_path, None, file_description, PATH_TYPE_FILE, PATH_PACKAGE_KIND_STANDARD, None) for file_path, file_description in job.filtered_data['files'].items()
                ]
            if len(job.filtered_data['folders']) > 0:
                job.directories_to_remove = [
                    PathPackage(folder_path, None, folder_description, PATH_TYPE_FOLDER, PATH_PACKAGE_KIND_STANDARD, None) for folder_path, folder_description in job.filtered_data['folders'].items()
                ]
        job.downloaded_files.extend(job.files_to_unzip)
        self._logger.bench('OpenZipContentsWorker precaching is_file...', job.db.db_id, job.zip_id)
        self._process_index_ctx.file_system.precache_is_file_with_folders(job.recipient_folders, recheck=True)
        self._logger.bench('OpenZipContentsWorker validating...', job.db.db_id, job.zip_id)
        existing_files, invalid_files = self._process_index_ctx.file_system.are_files(job.files_to_unzip)
        for file_pkg in existing_files:
            if self._process_index_ctx.file_system.hash(file_pkg.full_path) == file_pkg.description['hash']:
                job.validated_files.append(file_pkg)
            else:
                invalid_files.append(file_pkg)
        self._logger.bench('OpenZipContentsWorker validation done...', job.db.db_id, job.zip_id)
        if len(invalid_files) == 0:
            return [], None
        if job.zip_base_files_url == '':
            for file_pkg in invalid_files:
                if 'url' not in file_pkg.description:
                    job.failed_files.append(file_pkg)
        self._logger.bench('OpenZipContentsWorker launching recovery process index...', job.db.db_id, job.zip_id)
        return create_fetch_jobs(self._process_index_ctx, job.db.db_id, invalid_files, [], set(), job.zip_description.get('base_files_url', job.db.base_files_url)), None