from dataclasses import dataclass, field
from typing import Optional
from downloader.config import Config, ConfigDatabaseSection
from downloader.db_entity import DbEntity
from downloader.free_space_reservation import Partition
from downloader.job_system import Job, JobSystem
from downloader.jobs.index import Index
from downloader.local_store_wrapper import ReadOnlyStoreAdapter
from downloader.path_package import PathPackage
@dataclass(eq=False, order=False)
class ProcessDbIndexJob(Job):
    type_id: int = field(init=False, default=JobSystem.get_job_type_id())
    db: DbEntity
    store: ReadOnlyStoreAdapter
    ini_description: ConfigDatabaseSection
    index: Index
    config: Config
    zip_id: Optional[str] = None
    def retry_job(self): return None
    present_not_validated_files: list[PathPackage] = field(default_factory=list)
    verified_integrity_pkgs: list[PathPackage] = field(default_factory=list)
    failed_verification_pkgs: list[PathPackage] = field(default_factory=list)
    present_validated_files: list[PathPackage] = field(default_factory=list)
    skipped_updated_files: list[PathPackage] = field(default_factory=list)
    non_duplicated_files: list[PathPackage] = field(default_factory=list)
    duplicated_files: list[str] = field(default_factory=list)
    installed_folders: list[PathPackage] = field(default_factory=list)
    removed_folders: list[PathPackage] = field(default_factory=list)  #  @TODO: Why there is removed_folders AND directories_to_remove?
    directories_to_remove: list[PathPackage] = field(default_factory=list)
    files_to_remove: list[PathPackage] = field(default_factory=list)
    repeated_store_presence: set[str] = field(default_factory=set)
    full_partitions: list[tuple[Partition, int]] = field(default_factory=list)
    failed_files_no_space: list[PathPackage] = field(default_factory=list)
    failed_folders: list[str] = field(default_factory=list)