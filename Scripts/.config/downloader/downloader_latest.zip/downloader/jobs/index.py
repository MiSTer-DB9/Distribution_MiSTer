from dataclasses import dataclass
from typing import Dict, Any, Optional
@dataclass
class Index:
    files: Dict[str, Any]
    folders: Dict[str, Any]
