from dataclasses import field, dataclass
from downloader.config import Config, default_config, ConfigDatabaseSection
from downloader.constants import DB_STATE_SIGNATURE_NO_HASH, DB_STATE_SIGNATURE_NO_SIZE
from downloader.db_entity import DbEntity
from downloader.job_system import Job, JobSystem
from downloader.jobs.load_local_store_job import LoadLocalStoreJob
@dataclass(eq=False, order=False)
class MixStoreAndDbJob(Job):
    type_id: int = field(init=False, default=JobSystem.get_job_type_id())
    db: DbEntity
    ini_description: ConfigDatabaseSection
    load_local_store_job: LoadLocalStoreJob
    config: Config = field(default_factory=default_config)
    db_hash: str = field(default=DB_STATE_SIGNATURE_NO_HASH)
    db_size: int = field(default=DB_STATE_SIGNATURE_NO_SIZE)
    def retry_job(self): return None
    skipped: bool = field(default=False)
